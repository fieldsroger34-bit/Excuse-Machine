import React, { useState, useEffect, useCallback, useRef } from 'react';

// ─── STRIPE PAYMENT LINKS (YOUR LIVE LINKS) ──────────────────────────────────
const STRIPE_LINKS = {
  starter: "https://buy.stripe.com/aFadRb8VSgAd97E2n8frW0b",
  pro:     "https://buy.stripe.com/14A7sN6NKes5cjQ7HsfrW0c",
  mega:    "https://buy.stripe.com/6oU8wRb40abP83AbXIfrW0d",
};

// ─── CREDIT PACKAGES ─────────────────────────────────────────────────────────
const PACKAGES = [
  { id: 'starter', label: 'Starter',  credits: 5,  price: '$0.99', priceNote: '20¢ per excuse', emoji: '⚡', popular: false },
  { id: 'pro',     label: 'Pro',      credits: 20, price: '$2.99', priceNote: '15¢ per excuse', emoji: '🔥', popular: true  },
  { id: 'mega',    label: 'Mega',     credits: 60, price: '$6.99', priceNote: '12¢ per excuse', emoji: '💎', popular: false },
];

// ─── EXCUSE CATEGORIES ───────────────────────────────────────────────────────
const CATEGORIES = [
  { id: 'work',         label: 'Work',         emoji: '💼', free: true  },
  { id: 'school',       label: 'School',       emoji: '📚', free: true  },
  { id: 'relationship', label: 'Relationship', emoji: '💔', free: false },
  { id: 'family',       label: 'Family',       emoji: '🏠', free: false },
  { id: 'social',       label: 'Social',       emoji: '🎉', free: false },
  { id: 'health',       label: 'Health',       emoji: '🏥', free: false },
  { id: 'money',        label: 'Money',        emoji: '💸', free: false },
  { id: 'creative',     label: 'Wild Card',    emoji: '🎲', free: false },
];

// ─── URGENCY LEVELS ──────────────────────────────────────────────────────────
const URGENCY = [
  { id: 'mild',    label: 'Mild',       desc: 'Plausible & polite'      },
  { id: 'bold',    label: 'Bold',       desc: 'Dramatic but believable' },
  { id: 'nuclear', label: '☢️ Nuclear', desc: 'Pull out all the stops'  },
];

// ─── STORAGE HELPERS ─────────────────────────────────────────────────────────
const STORAGE_KEY = 'excuse_machine_v1';
const load = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
};
const save = (data) => {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
  catch {}
};

// ─── EXCUSE GENERATION ───────────────────────────────────────────────────────
// NOTE: Calls /api/excuse — a Vercel serverless function (see api/excuse.js)
// This keeps your Anthropic API key secret on the server side.
async function generateExcuse(category, urgency, context, isPremium) {
  const response = await fetch('/api/excuse', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ category, urgency, context, isPremium }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'API error');
  }

  const data = await response.json();
  return data.excuse || 'Something went wrong. Even our excuse machine needs an excuse sometimes.';
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────
export default function App() {
  const stored = load();

  const [credits,     setCredits]     = useState(stored.credits     ?? 0);
  const [freeUsed,    setFreeUsed]    = useState(stored.freeUsed    ?? 0);
  const [category,    setCategory]    = useState('work');
  const [urgency,     setUrgency]     = useState('mild');
  const [context,     setContext]     = useState('');
  const [excuse,      setExcuse]      = useState('');
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState('');
  const [showPaywall, setShowPaywall] = useState(false);
  const [copied,      setCopied]      = useState(false);
  const [history,     setHistory]     = useState(stored.history     ?? []);
  const [showHistory, setShowHistory] = useState(false);
  const [particles,   setParticles]   = useState([]);
  const excuseRef = useRef(null);

  const FREE_LIMIT     = 3;
  const isPremium      = credits > 0;
  const selectedCat    = CATEGORIES.find(c => c.id === category);
  const isFreeCategory = selectedCat?.free;
  const canGenerate    = isFreeCategory
    ? (freeUsed < FREE_LIMIT || credits > 0)
    : credits > 0;

  // Persist state
  useEffect(() => {
    save({ credits, freeUsed, history });
  }, [credits, freeUsed, history]);

  // Handle Stripe redirect — ?pkg=starter|pro|mega
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pkg = params.get('pkg');
    if (pkg) {
      const found = PACKAGES.find(p => p.id === pkg);
      if (found) {
        setCredits(c => {
          const next = c + found.credits;
          save({ credits: next, freeUsed, history });
          return next;
        });
        window.history.replaceState({}, '', '/');
        triggerParticles();
      }
    }
  }, []); // eslint-disable-line

  const triggerParticles = () => {
    const p = Array.from({ length: 18 }, (_, i) => ({
      id: i,
      x: 40 + Math.random() * 20,
      y: 40 + Math.random() * 20,
      dx: (Math.random() - 0.5) * 200,
      dy: (Math.random() - 0.5) * 200,
      emoji: ['💰','✨','🎉','⚡','💎'][Math.floor(Math.random() * 5)],
    }));
    setParticles(p);
    setTimeout(() => setParticles([]), 1200);
  };

  const handleGenerate = useCallback(async () => {
    if (loading) return;

    if (!isFreeCategory && credits <= 0) { setShowPaywall(true); return; }
    if (isFreeCategory && freeUsed >= FREE_LIMIT && credits <= 0) { setShowPaywall(true); return; }

    setLoading(true);
    setError('');
    setExcuse('');
    setCopied(false);

    try {
      const result = await generateExcuse(category, urgency, context, isPremium);
      setExcuse(result);

      if (credits > 0) {
        setCredits(c => c - 1);
      } else {
        setFreeUsed(f => f + 1);
      }

      const entry = {
        id: Date.now(),
        category: selectedCat?.emoji + ' ' + selectedCat?.label,
        urgency,
        text: result,
        ts: new Date().toLocaleTimeString(),
      };
      setHistory(h => [entry, ...h].slice(0, 20));

      setTimeout(() => excuseRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
    } catch (e) {
      setError('The machine broke down. Even excuses need excuses. Try again!');
    } finally {
      setLoading(false);
    }
  }, [loading, isFreeCategory, credits, freeUsed, category, urgency, context, isPremium, selectedCat]);

  const handleCopy = () => {
    const watermarked = `${excuse}\n\n— Generated by ExcuseMachine™ at aivaultco.com`;
    navigator.clipboard.writeText(watermarked).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const freeLeft = Math.max(0, FREE_LIMIT - freeUsed);

  return (
    <div style={styles.root}>
      {/* Background */}
      <div style={styles.bgGrid} />
      <div style={styles.bgGlow1} />
      <div style={styles.bgGlow2} />

      {/* Particles */}
      {particles.map(p => (
        <div
          key={p.id}
          style={{
            ...styles.particle,
            left: `${p.x}%`,
            top: `${p.y}%`,
            '--dx': `${p.dx}px`,
            '--dy': `${p.dy}px`,
          }}
        >{p.emoji}</div>
      ))}

      <div style={styles.container}>
        {/* Header */}
        <header style={styles.header}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>💬</span>
            <div>
              <div style={styles.logoTitle}>Excuse Machine™</div>
              <div style={styles.logoSub}>AI-powered excuses for every situation</div>
            </div>
          </div>
          <div style={styles.headerRight}>
            {credits > 0 && (
              <div style={styles.creditBadge}>
                ⚡ {credits} credit{credits !== 1 ? 's' : ''}
              </div>
            )}
            <button
              style={styles.histBtn}
              onClick={() => setShowHistory(s => !s)}
            >
              {showHistory ? 'Hide' : 'History'}
            </button>
          </div>
        </header>

        {/* History panel */}
        {showHistory && (
          <div style={styles.historyPanel}>
            <div style={styles.historyHeader}>
              <span>Recent Excuses</span>
              <button style={styles.closeBtn} onClick={() => setShowHistory(false)}>✕</button>
            </div>
            {history.length === 0
              ? <div style={styles.histEmpty}>No excuses yet. Generate your first one!</div>
              : history.map(item => (
                <div key={item.id} style={styles.histItem}>
                  <div style={styles.histMeta}>{item.category} · {item.urgency} · {item.ts}</div>
                  <div style={styles.histText}>{item.text}</div>
                </div>
              ))
            }
          </div>
        )}

        {/* Social proof */}
        <div style={styles.socialProof}>
          <div style={styles.statRow}>
            {['10,000+ excuses generated','Works in 8 categories','3 free excuses daily'].map((s, i) => (
              <div key={i} style={styles.stat}>{s}</div>
            ))}
          </div>
        </div>

        {/* Category */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>What do you need an excuse for?</div>
          <div style={styles.categoryGrid}>
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                style={{
                  ...styles.catBtn,
                  ...(category === cat.id ? styles.catBtnActive : {}),
                  ...(!cat.free && credits <= 0 ? styles.catBtnLocked : {}),
                }}
                onClick={() => setCategory(cat.id)}
              >
                {!cat.free && credits <= 0 && <span style={styles.lockBadge}>🔒</span>}
                <span style={styles.catEmoji}>{cat.emoji}</span>
                <span style={styles.catLabel}>{cat.label}</span>
              </button>
            ))}
          </div>
          {credits <= 0 && (
            <div style={styles.freeNote}>
              🆓 Work & School are free · Unlock all categories with credits
            </div>
          )}
        </div>

        {/* Urgency */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>Urgency level</div>
          <div style={styles.urgencyRow}>
            {URGENCY.map(u => (
              <button
                key={u.id}
                style={{ ...styles.urgBtn, ...(urgency === u.id ? styles.urgBtnActive : {}) }}
                onClick={() => setUrgency(u.id)}
              >
                <span style={styles.urgLabel}>{u.label}</span>
                <span style={styles.urgDesc}>{u.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Context */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>
            Extra context <span style={styles.optional}>(optional — makes it more convincing)</span>
          </div>
          <textarea
            style={styles.textarea}
            rows={2}
            placeholder="e.g. 'my boss is strict about tardiness' or 'I already cancelled twice'"
            value={context}
            onChange={e => setContext(e.target.value)}
            maxLength={200}
          />
        </div>

        {/* Generate button */}
        <div style={styles.genSection}>
          {isFreeCategory && credits <= 0 && freeLeft > 0 && (
            <div style={styles.freeCounter}>
              {freeLeft} free excuse{freeLeft !== 1 ? 's' : ''} remaining today
            </div>
          )}
          <button
            style={{
              ...styles.genBtn,
              ...(loading ? styles.genBtnLoading : {}),
              ...(!canGenerate ? styles.genBtnLocked : {}),
            }}
            onClick={canGenerate ? handleGenerate : () => setShowPaywall(true)}
            disabled={loading}
          >
            <div style={styles.genBtnInner}>
              {loading && <span style={styles.spinner} />}
              {loading ? 'Crafting your excuse...' : canGenerate ? '⚡ Generate My Excuse' : '🔒 Get Credits to Unlock'}
            </div>
          </button>
        </div>

        {/* Error */}
        {error && <div style={styles.errorBox}>{error}</div>}

        {/* Result */}
        {excuse && (
          <div ref={excuseRef} style={styles.resultSection}>
            <div style={styles.resultCard}>
              <div style={styles.resultHeader}>
                <span style={styles.resultLabel}>Your Excuse</span>
                {isPremium && <span style={styles.premiumTag}>⚡ Premium</span>}
              </div>
              <p style={styles.resultText}>{excuse}</p>
              <div style={styles.resultActions}>
                <button style={styles.copyBtn} onClick={handleCopy}>
                  {copied ? '✓ Copied!' : '📋 Copy'}
                </button>
                <button style={styles.regenBtn} onClick={handleGenerate} disabled={loading}>
                  🔄 New Excuse
                </button>
              </div>
              {copied && <div style={styles.copiedNote}>Copied with watermark — remove it if you want</div>}
              <div style={styles.watermark}>ExcuseMachine™ · aivaultco.com</div>
            </div>
          </div>
        )}

        {/* Footer */}
        <footer style={styles.footer}>
          <div>ExcuseMachine™ · <a href="https://aivaultco.com" style={{ color: '#555' }}>aivaultco.com</a></div>
          <div style={styles.footerSub}>For entertainment purposes · Use responsibly</div>
        </footer>
      </div>

      {/* Paywall Modal */}
      {showPaywall && (
        <div style={styles.modalOverlay} onClick={e => { if (e.target === e.currentTarget) setShowPaywall(false); }}>
          <div style={styles.modal}>
            <button style={styles.modalClose} onClick={() => setShowPaywall(false)}>✕</button>
            <div style={styles.modalHead}>
              <span style={styles.modalEmoji}>💬</span>
              <div style={styles.modalTitle}>Get Premium Excuses</div>
              <div style={styles.modalSub}>Credits never expire · Unlock all 8 categories · AI-powered</div>
            </div>
            <div style={styles.packagesGrid}>
              {PACKAGES.map(pkg => (
                <div
                  key={pkg.id}
                  style={{ ...styles.pkgCard, ...(pkg.popular ? styles.pkgCardPopular : {}) }}
                >
                  {pkg.popular && <div style={styles.pkgBadge}>MOST POPULAR</div>}
                  <div style={styles.pkgEmoji}>{pkg.emoji}</div>
                  <div style={styles.pkgName}>{pkg.label}</div>
                  <div style={styles.pkgCredits}>{pkg.credits} Credits</div>
                  <div style={styles.pkgPrice}>{pkg.price}</div>
                  <div style={styles.pkgNote}>{pkg.priceNote}</div>
                  <a
                    href={`${STRIPE_LINKS[pkg.id]}?success_url=${encodeURIComponent(window.location.origin + '/?pkg=' + pkg.id)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ ...styles.buyBtn, ...(pkg.popular ? styles.buyBtnPopular : {}) }}
                  >
                    Get {pkg.label}
                  </a>
                </div>
              ))}
            </div>
            <p style={styles.modalGuarantee}>
              🔒 Secure payment via Stripe · Credits added instantly · 30-day refund guarantee
            </p>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:ital,wght@0,400;0,500;1,400&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Syne', sans-serif; }
        button { cursor: pointer; font-family: 'Syne', sans-serif; }
        button:focus-visible { outline: 2px solid #7c3aed; outline-offset: 2px; }
        @keyframes spin     { to { transform: rotate(360deg); } }
        @keyframes fadeUp   { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        @keyframes glow     { 0%,100% { opacity:0.4; } 50% { opacity:0.7; } }
        @keyframes particleFly {
          0%   { transform: translate(0,0) scale(1); opacity:1; }
          100% { transform: translate(var(--dx), var(--dy)) scale(0); opacity:0; }
        }
        ::-webkit-scrollbar       { width: 6px; }
        ::-webkit-scrollbar-track { background: #0d0d1a; }
        ::-webkit-scrollbar-thumb { background: #2a2a4a; border-radius: 3px; }
        @media (max-width: 480px) {
          .cat-grid { grid-template-columns: repeat(2, 1fr) !important; }
          .pkg-grid  { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

// ─── STYLES ──────────────────────────────────────────────────────────────────
const styles = {
  root: { minHeight: '100vh', background: '#080810', color: '#e8e8f0', position: 'relative', overflowX: 'hidden' },
  bgGrid: {
    position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
    backgroundImage: `linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)`,
    backgroundSize: '40px 40px',
  },
  bgGlow1: { position: 'fixed', top: '-20%', left: '-10%', width: '60%', height: '60%', background: 'radial-gradient(circle, rgba(120,80,255,0.15) 0%, transparent 70%)', zIndex: 0, pointerEvents: 'none', animation: 'glow 6s ease-in-out infinite' },
  bgGlow2: { position: 'fixed', bottom: '-20%', right: '-10%', width: '50%', height: '50%', background: 'radial-gradient(circle, rgba(255,80,120,0.1) 0%, transparent 70%)', zIndex: 0, pointerEvents: 'none', animation: 'glow 8s ease-in-out infinite 2s' },
  particle: { position: 'fixed', zIndex: 1000, fontSize: '24px', pointerEvents: 'none', animation: 'particleFly 1.2s ease-out forwards' },
  container: { position: 'relative', zIndex: 1, maxWidth: '760px', margin: '0 auto', padding: '24px 20px 80px' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px', paddingBottom: '20px', borderBottom: '1px solid rgba(255,255,255,0.07)' },
  logo: { display: 'flex', alignItems: 'center', gap: '14px' },
  logoIcon: { fontSize: '36px' },
  logoTitle: { fontFamily:"'Syne',sans-serif", fontWeight: 800, fontSize: '22px', letterSpacing: '-0.5px', background: 'linear-gradient(135deg, #ffffff 0%, #a78bfa 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' },
  logoSub: { fontSize: '12px', color: '#666680', marginTop: '2px' },
  headerRight: { display: 'flex', alignItems: 'center', gap: '12px' },
  creditBadge: { display: 'flex', alignItems: 'center', gap: '6px', background: 'linear-gradient(135deg, #7c3aed, #4f46e5)', padding: '6px 14px', borderRadius: '20px', fontSize: '13px', fontWeight: 700 },
  histBtn: { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#b0b0c8', padding: '7px 14px', borderRadius: '8px', fontSize: '13px', fontFamily:"'Syne',sans-serif", transition: 'all 0.2s' },
  historyPanel: { background: '#0f0f1e', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', padding: '16px', marginBottom: '28px', maxHeight: '300px', overflowY: 'auto', animation: 'fadeUp 0.2s ease' },
  historyHeader: { display: 'flex', justifyContent: 'space-between', fontWeight: 700, marginBottom: '12px', color: '#a78bfa' },
  closeBtn: { background: 'none', border: 'none', color: '#666', cursor: 'pointer', fontSize: '16px' },
  histEmpty: { color: '#555', fontSize: '14px', textAlign: 'center', padding: '20px 0' },
  histItem: { borderBottom: '1px solid rgba(255,255,255,0.05)', paddingBottom: '10px', marginBottom: '10px' },
  histMeta: { fontSize: '11px', color: '#555', marginBottom: '4px', fontFamily:"'DM Mono',monospace" },
  histText: { fontSize: '13px', color: '#c0c0d8', lineHeight: '1.5' },
  socialProof: { marginBottom: '28px' },
  statRow: { display: 'flex', gap: '10px' },
  stat: { flex: 1, textAlign: 'center', fontSize: '12px', color: '#505070', background: 'rgba(255,255,255,0.03)', borderRadius: '8px', padding: '10px', border: '1px solid rgba(255,255,255,0.05)' },
  section: { marginBottom: '28px' },
  sectionTitle: { fontSize: '13px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#7070a0', marginBottom: '12px' },
  optional: { fontWeight: 400, opacity: 0.6, textTransform: 'none', letterSpacing: 0 },
  categoryGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' },
  catBtn: { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '12px 8px', cursor: 'pointer', color: '#b0b0c8', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', fontFamily:"'Syne',sans-serif", transition: 'all 0.18s', position: 'relative' },
  catBtnActive: { background: 'rgba(124,58,237,0.2)', border: '1px solid #7c3aed', color: '#e0d0ff' },
  catBtnLocked: { opacity: 0.6 },
  catEmoji: { fontSize: '22px' },
  catLabel: { fontSize: '12px', fontWeight: 600 },
  lockBadge: { position: 'absolute', top: '5px', right: '6px', fontSize: '10px', background: 'rgba(124,58,237,0.5)', borderRadius: '4px', padding: '1px 4px' },
  freeNote: { fontSize: '12px', color: '#555', marginTop: '10px' },
  urgencyRow: { display: 'flex', gap: '10px' },
  urgBtn: { flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '12px', cursor: 'pointer', color: '#b0b0c8', fontFamily:"'Syne',sans-serif", display: 'flex', flexDirection: 'column', gap: '4px', transition: 'all 0.18s' },
  urgBtnActive: { background: 'rgba(239,68,68,0.15)', border: '1px solid #ef4444', color: '#fca5a5' },
  urgLabel: { fontWeight: 700, fontSize: '14px' },
  urgDesc: { fontSize: '11px', opacity: 0.6 },
  textarea: { width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', color: '#e0e0f0', fontFamily:"'DM Mono',monospace", fontSize: '13px', padding: '12px', resize: 'none', outline: 'none', lineHeight: '1.5', transition: 'border-color 0.2s' },
  genSection: { textAlign: 'center', marginBottom: '28px' },
  freeCounter: { fontSize: '13px', color: '#a78bfa', marginBottom: '12px', fontWeight: 600 },
  genBtn: { width: '100%', padding: '18px', background: 'linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)', border: 'none', borderRadius: '12px', color: '#fff', fontSize: '17px', fontWeight: 800, fontFamily:"'Syne',sans-serif", letterSpacing: '0.02em', transition: 'all 0.2s', boxShadow: '0 8px 32px rgba(124,58,237,0.35)' },
  genBtnLoading: { opacity: 0.7, cursor: 'wait' },
  genBtnLocked: { background: 'linear-gradient(135deg, #2a2a4a 0%, #1a1a2e 100%)', boxShadow: 'none' },
  genBtnInner: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' },
  spinner: { display: 'inline-block', width: '18px', height: '18px', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.7s linear infinite' },
  resultSection: { marginBottom: '28px', animation: 'fadeUp 0.3s ease' },
  resultCard: { background: 'linear-gradient(135deg, rgba(124,58,237,0.12) 0%, rgba(79,70,229,0.08) 100%)', border: '1px solid rgba(124,58,237,0.3)', borderRadius: '14px', padding: '24px' },
  resultHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' },
  resultLabel: { fontSize: '12px', color: '#a78bfa', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' },
  premiumTag: { fontSize: '11px', background: 'rgba(124,58,237,0.3)', padding: '3px 8px', borderRadius: '4px', color: '#c4b5fd' },
  resultText: { fontSize: '17px', lineHeight: '1.7', color: '#f0f0ff', fontFamily:"'DM Mono',monospace", fontStyle: 'italic', marginBottom: '20px' },
  resultActions: { display: 'flex', gap: '10px', marginBottom: '12px' },
  copyBtn: { flex: 1, background: 'rgba(124,58,237,0.25)', border: '1px solid rgba(124,58,237,0.4)', borderRadius: '8px', color: '#c4b5fd', padding: '10px', fontFamily:"'Syne',sans-serif", fontWeight: 700, fontSize: '14px', transition: 'all 0.2s' },
  regenBtn: { flex: 1, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#909090', padding: '10px', fontFamily:"'Syne',sans-serif", fontWeight: 700, fontSize: '14px', transition: 'all 0.2s' },
  watermark: { fontSize: '10px', color: '#333350', textAlign: 'right', fontFamily:"'DM Mono',monospace" },
  copiedNote: { fontSize: '12px', color: '#6b7280', marginTop: '8px', textAlign: 'center' },
  errorBox: { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '10px', padding: '16px', color: '#fca5a5', fontSize: '14px', marginBottom: '20px' },
  footer: { textAlign: 'center', color: '#333350', fontSize: '11px', lineHeight: '1.8' },
  footerSub: { marginTop: '4px', opacity: 0.7 },
  modalOverlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', backdropFilter: 'blur(4px)' },
  modal: { background: '#0f0f1e', border: '1px solid rgba(124,58,237,0.3)', borderRadius: '20px', padding: '32px', width: '100%', maxWidth: '520px', position: 'relative', animation: 'fadeUp 0.25s ease', maxHeight: '90vh', overflowY: 'auto' },
  modalClose: { position: 'absolute', top: '16px', right: '16px', background: 'none', border: 'none', color: '#555', cursor: 'pointer', fontSize: '20px' },
  modalHead: { textAlign: 'center', marginBottom: '28px' },
  modalEmoji: { fontSize: '40px', display: 'block', marginBottom: '12px' },
  modalTitle: { fontSize: '24px', fontWeight: 800, marginBottom: '8px', color: '#f0f0ff' },
  modalSub: { color: '#707090', fontSize: '14px' },
  packagesGrid: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginBottom: '20px' },
  pkgCard: { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', padding: '18px 12px', textAlign: 'center', position: 'relative', transition: 'all 0.2s' },
  pkgCardPopular: { background: 'rgba(124,58,237,0.15)', border: '1px solid #7c3aed' },
  pkgBadge: { position: 'absolute', top: '-10px', left: '50%', transform: 'translateX(-50%)', background: '#7c3aed', color: '#fff', fontSize: '9px', fontWeight: 800, padding: '3px 8px', borderRadius: '4px', letterSpacing: '0.05em', whiteSpace: 'nowrap' },
  pkgEmoji: { fontSize: '28px', marginBottom: '8px' },
  pkgName: { fontWeight: 700, fontSize: '14px', marginBottom: '4px' },
  pkgCredits: { fontSize: '20px', fontWeight: 800, color: '#a78bfa', marginBottom: '4px' },
  pkgPrice: { fontSize: '22px', fontWeight: 800, color: '#f0f0ff', marginBottom: '2px' },
  pkgNote: { fontSize: '11px', color: '#555', marginBottom: '12px' },
  buyBtn: { display: 'block', width: '100%', padding: '10px', background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '8px', color: '#d0d0f0', textDecoration: 'none', fontFamily:"'Syne',sans-serif", fontWeight: 700, fontSize: '13px', transition: 'all 0.2s' },
  buyBtnPopular: { background: 'linear-gradient(135deg, #7c3aed, #4f46e5)', border: 'none', color: '#fff', boxShadow: '0 4px 16px rgba(124,58,237,0.4)' },
  modalGuarantee: { textAlign: 'center', fontSize: '12px', color: '#444460' },
};
