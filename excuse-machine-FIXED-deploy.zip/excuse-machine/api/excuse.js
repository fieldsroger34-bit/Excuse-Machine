// api/excuse.js — Vercel Serverless Function
// This runs on the SERVER so your Anthropic API key stays secret.
// The React app calls /api/excuse — Vercel routes it here automatically.

const CATEGORIES = {
  work: 'work or professional',
  school: 'school or academic',
  relationship: 'romantic relationship',
  family: 'family',
  social: 'social event or friend group',
  health: 'health or medical',
  money: 'financial or money',
  creative: 'any creative or wild scenario',
};

const URGENCY_TONES = {
  mild: 'calm, rational, and completely plausible. No drama.',
  bold: 'slightly dramatic and hard to argue with. Add a specific convincing detail.',
  nuclear: 'emotionally devastating. Maximum sympathy. Pull out all the stops.',
};

export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { category, urgency, context, isPremium } = req.body || {};

  // Validate inputs
  if (!category || !urgency) {
    return res.status(400).json({ error: 'Missing category or urgency' });
  }

  const categoryLabel = CATEGORIES[category] || category;
  const urgencyTone   = URGENCY_TONES[urgency] || URGENCY_TONES.mild;

  const systemPrompt = `You are the Excuse Machine™ — a wickedly clever AI that crafts the perfect excuse for any situation.

You write excuses that are:
- Believable enough to work, with just the right amount of detail
- Specific (vague excuses get caught)
- Emotionally resonant — people feel bad saying no to a good excuse
- Occasionally funny, always effective
- NEVER generic. Every excuse is unique.

Tone: ${urgencyTone}
${isPremium ? 'This is a PREMIUM excuse — make it extraordinary. Add an irrefutable specific detail.' : ''}

Respond with ONLY the excuse text — no intro, no quotes, no explanation. 2-4 sentences max. Make it vivid.`;

  const userPrompt = `Category: ${categoryLabel}
Urgency: ${urgency}${context ? `\nExtra context: ${context}` : ''}

Generate the perfect excuse now.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic error:', errText);
      return res.status(500).json({ error: 'AI service error. Please try again.' });
    }

    const data = await response.json();
    const excuse = data.content?.[0]?.text?.trim();

    if (!excuse) {
      return res.status(500).json({ error: 'No excuse generated. Please try again.' });
    }

    return res.status(200).json({ excuse });

  } catch (err) {
    console.error('Handler error:', err);
    return res.status(500).json({ error: 'Server error. Please try again.' });
  }
}
